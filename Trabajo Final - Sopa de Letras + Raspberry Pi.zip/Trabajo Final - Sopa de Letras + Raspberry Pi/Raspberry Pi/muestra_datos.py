
import PySimpleGUI as sg
from funciones_muestra_temperatura import mostrar


#  -----Configuro al GUI-----
layout = [[sg.Text('Muestra Ambiental', size=(28, 2), font='Arial', text_color='black')],
          [sg.Button('Comenzar', key='comenzar', size=(20, 1), button_color=('white', 'red'),
                     font=('Arial', 12, 'bold')),
           sg.CloseButton('Cerrar', size=(20, 1), button_color=('white', 'red'), font=('Arial', 12, 'bold'),
                          key='cerrar')]]

#  -----Muestro la GUI-----
window = sg.Window('Muestra Ambiental', element_padding=(0, 2), auto_size_buttons=False,
                   grab_anywhere=True).Layout(layout)
while True:
    event, values = window.Read()
    if event is None:
        break
    if event == 'comenzar':
        #  -----Llama a funcion que ejecuta los modulos-----#
        mostrar()
